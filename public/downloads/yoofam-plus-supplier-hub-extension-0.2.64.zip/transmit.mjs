import {validateHandoff,transferRecord,resultKey} from './handoff-store.mjs';
import {validateAppHubRequest,isHubRegistrationTab} from './app-request.mjs';
import {prepareAttachments} from './package.mjs';
import {verifySupplierHubCompany} from './company.mjs';
import {attachToSupplierHub} from './attach.mjs';
import {requestSupplierHubValidation} from './validate.mjs';
import {isSupplierHubTab,waitForSupplierHubPage,supplierHubUploadReady} from './hub-tab.mjs';
import {verifyAppQuotationSource} from './source-check.mjs';
import {claimSupplierHubTransmissionWindow} from './transmission-window.mjs';
import {assertAppSupplierHubNotSubmitted} from './receipt-recovery.mjs';

export async function transmitSupplierHubPackage(message,sender,api=chrome,store=transferRecord){
  const identity=validateAppHubRequest(message,sender,'YOOFAM_TRANSMIT_PACKAGE');
  const reviewed=message.reviewedAgreements;
  const choices=['priceData','labelBusinessContact','legalDocumentsNotApplicable','legalDocumentsRequired'];
  if(!reviewed||typeof reviewed!=='object'||Array.isArray(reviewed)
    ||Object.keys(reviewed).some(key=>!choices.includes(key))||Object.values(reviewed).some(value=>typeof value!=='boolean')||reviewed.priceData!==true||reviewed.labelBusinessContact!==true||!(reviewed.legalDocumentsNotApplicable===true&&reviewed.legalDocumentsRequired!==true||reviewed.legalDocumentsRequired===true&&reviewed.legalDocumentsNotApplicable===false))
    throw Error('가격 정보·라벨 연락처 동의와 법적 서류 해당 여부를 확인해주세요.');
  const packageValue=validateHandoff({...message,type:'YOOFAM_PREPARE_PACKAGE'},sender);
  const windowId=sender.tab.windowId;
  const release=claimSupplierHubTransmissionWindow(windowId);
  try{
    const prepared=await prepareAttachments(Uint8Array.from(atob(packageValue.base64),c=>c.charCodeAt(0)));
    if((prepared.legalDocumentsRequired===true)!==(reviewed.legalDocumentsRequired===true))throw Error('검토한 법적 서류 해당 여부와 첨부 패키지가 다릅니다.');
    if(prepared.productId!==identity.productId||prepared.categoryId!==identity.categoryId
      ||prepared.quotation[0]?.name!==`YOOFAM-${identity.fingerprint}.xlsx`)throw Error('검토한 상품·카테고리와 첨부 견적서가 다릅니다.');
    const sourceCheck=()=>verifyAppQuotationSource(identity,prepared,{appTabId:sender.tab.id,windowId},api);
    await sourceCheck();
    const key=`transmission:${identity.origin}:${identity.productId}:${identity.categoryId}:${identity.fingerprint}`;
    if(await store('get',key))throw Error('이 견적서는 이미 전송을 시도했습니다. 검증 결과를 확인해주세요. 자동으로 다시 첨부하지 않습니다.');
    if(await store('get',resultKey(identity)))throw Error('이 견적서는 이미 접수 결과가 있습니다. 상품별 상태를 조회해주세요. 다시 첨부하지 않습니다.');
    const receiptCheck=()=>assertAppSupplierHubNotSubmitted(identity,prepared,{appTabId:sender.tab.id,windowId},api,store);
    await receiptCheck();
    const tabs=(await api.tabs.query({windowId,url:'https://supplier.coupang.com/qvt/registration*'})).filter(tab=>isHubRegistrationTab(tab,windowId));
    const unused=[],owned=[];
    for(const tab of tabs){
      const attempt=await store('get',`attempt:${tab.id}`);
      if(!attempt)unused.push(tab);
      else if(attempt.origin===identity.origin&&attempt.company?.code===prepared.company.code&&attempt.company?.name===prepared.company.name)owned.push(tab);
    }
    if(unused.length>1||(tabs.length&&!unused.length&&!owned.length))throw Error('앱과 같은 Chrome 창의 Supplier Hub 대량 상품 등록 탭을 확인해주세요. 작업 중인 탭이 여러 개면 사용할 탭을 하나 남겨주세요.');
    let tabId=(unused[0]||owned[0])?.id;
    const current=async()=>{const tab=await api.tabs.get(tabId);if(!isHubRegistrationTab(tab,windowId))throw Error('Supplier Hub 탭이 이동되거나 등록 화면이 변경되었습니다.');};
    const companyCheck=async()=>{
      await current();
      const [execution]=await api.scripting.executeScript({target:{tabId},func:verifySupplierHubCompany,args:[prepared.company]});
      if(execution?.result?.code!==prepared.company.code)throw Error('회원 회사와 Supplier Hub 회사코드가 일치하지 않습니다.');
      await current();
    };
    let preflight;
    const prepareFreshTab=async()=>{
      const fresh=await api.tabs.create({windowId,url:'https://supplier.coupang.com/qvt/registration',active:false});
      if(!Number.isSafeInteger(fresh?.id)||fresh.id<0||fresh.windowId!==windowId)throw Error('같은 Chrome 창에 새 등록 탭을 준비하지 못했습니다.');
      tabId=fresh.id;
      await waitForSupplierHubPage(tabId,windowId,'/qvt/registration',supplierHubUploadReady,api);
      await companyCheck();
      [preflight]=await api.scripting.executeScript({target:{tabId},func:attachToSupplierHub,args:[prepared,true]});
    };
    if(!tabs.length){
      // Read the company from an existing logged-in dashboard or status page.
      // Preserve that user's page and use a fresh form only after the checks.
      const loggedInPages=(await api.tabs.query({windowId,url:['https://supplier.coupang.com/dashboard/KR*','https://supplier.coupang.com/qvt/wims*']}))
        .filter(tab=>!tab.pendingUrl);
      const dashboards=loggedInPages.filter(tab=>isSupplierHubTab(tab,windowId,'/dashboard/KR'));
      // Preserve the established dashboard path even if status pages coexist.
      const anchors=dashboards.length?dashboards:loggedInPages.filter(tab=>isSupplierHubTab(tab,windowId,'/qvt/wims'));
      if(anchors.length!==1)throw Error('앱과 같은 Chrome 창에 로그인된 Supplier Hub 대시보드·견적서 등록 상태 또는 대량 상품 등록 탭을 열어두세요. 사용할 대시보드·등록 상태 탭은 하나만 남겨주세요.');
      const anchorId=anchors[0].id,anchorPath=new URL(anchors[0].url).pathname;
      const checkAnchor=async()=>{const tab=await api.tabs.get(anchorId);if(tab?.id!==anchorId||tab.pendingUrl||!isSupplierHubTab(tab,windowId,anchorPath))throw Error('Supplier Hub 화면이 이동되거나 로그인 상태가 변경되었습니다.');};
      await checkAnchor();
      const [company]=await api.scripting.executeScript({target:{tabId:anchorId},func:verifySupplierHubCompany,args:[prepared.company,'catalog']});
      if(company?.result?.code!==prepared.company.code)throw Error('회원 회사와 Supplier Hub 회사코드가 일치하지 않습니다.');
      await checkAnchor();
      await sourceCheck();
      await receiptCheck();
      await checkAnchor();
      await prepareFreshTab();
    }else{
      await companyCheck();
      if(unused.length)[preflight]=await api.scripting.executeScript({target:{tabId},func:attachToSupplierHub,args:[prepared,true]});
      if(!unused.length||preflight?.result?.state==='occupied'){
        // Preserve the original file inputs, agreements and validation history.
        await companyCheck();
        await prepareFreshTab();
      }
    }
    if(preflight?.result?.state!=='ready'||preflight.result.registered!==false)throw Error('Supplier Hub 첨부 화면을 확인하지 못했습니다.');
    await current();
    await sourceCheck();
    await receiptCheck();
    const record={...identity,company:prepared.company,includedOptions:prepared.includedOptions,profileId:prepared.profileId,
      filename:prepared.quotation[0].name,attachmentNames:[...prepared.quotation,...prepared.productImages,...prepared.labelImages,...(prepared.legalDocuments??[])].map(file=>file.name),
      legalDocuments:(prepared.legalDocuments??[]).map(file=>file.name),legalDocumentsRequired:prepared.legalDocumentsRequired===true,
      validationResume:true,tabId,windowId,startedAt:Date.now(),state:'started',registered:false};
    // Atomic persisted claim survives a closed app tab or a restarted worker.
    if(!await store('claim',key,record))throw Error('이 견적서는 이미 전송을 시도했습니다. 검증 결과를 확인해주세요. 자동으로 다시 첨부하지 않습니다.');
    let attached=false;
    try{
      await current();
      // Bind the lookup before a change event can start an upload. A partial
      // attachment or lost script reply must still be readable without replay.
      await store('put',`attempt:${tabId}`,{...identity,company:prepared.company,includedOptions:prepared.includedOptions});
      const [execution]=await api.scripting.executeScript({target:{tabId},func:attachToSupplierHub,args:[prepared]});
      const result=execution?.result;
      if(!result||!['dispatched','partial'].includes(result.state)||result.registered!==false)throw Error('파일 전달 결과를 확인하지 못했습니다. Supplier Hub 첨부 목록을 확인해주세요.');
      if(result.state==='partial'){
        const outcome={state:'partial',registered:false,error:result.error||'첨부 일부만 전달했습니다. Supplier Hub에서 파일을 확인해주세요.'};
        await store('put',key,{...record,...outcome});return outcome;
      }
      attached=true;
      await store('put',key,{...record,state:'attached'});
      await companyCheck();
      const names=[...prepared.quotation,...prepared.productImages,...prepared.labelImages,...(prepared.legalDocuments??[])].map(file=>file.name);
      const [ready]=await api.scripting.executeScript({target:{tabId},func:waitForSupplierHubAttachments,args:[names,prepared.company]});
      if(ready?.result!==true)throw Error('파일 업로드 완료를 확인하지 못했습니다. Supplier Hub 첨부 목록을 확인해주세요.');
      await companyCheck();
      await sourceCheck();
      const [validation]=await api.scripting.executeScript({target:{tabId},func:requestSupplierHubValidation,args:[reviewed,true]});
      const outcome=validation?.result;
      if(outcome?.state!=='validation-requested'||outcome.validated!==false||outcome.registered!==false)throw Error('파일 검증 요청 결과를 확인하지 못했습니다. Supplier Hub 진행상태를 확인해주세요.');
      await store('put',key,{...record,...outcome});return outcome;
    }catch(error){
      const outcome={state:attached?'attached':'unconfirmed',registered:false,error:String(error?.message||error)};
      await store('put',key,{...record,...outcome});return outcome;
    }
  }finally{release();}
}

// Wait only for the files from this attempt. Never retry an upload or read cookies.
export async function waitForSupplierHubAttachments(names,company){
  if(!Array.isArray(names)||!names.length||names.some(name=>typeof name!=='string'))throw Error('첨부 목록을 확인해주세요.');
  const readCurrent=()=>{
    if(location.origin!=='https://supplier.coupang.com'||location.pathname!=='/qvt/registration')throw Error('Supplier Hub 등록 화면이 변경되었습니다.');
    let value;try{value=JSON.parse(document.documentElement.dataset.yoofamAttachmentAttempt||'');}catch{throw Error('첨부 시도 기록이 없습니다.');}
    if(value.state!=='dispatched'||value.company?.code!==company.code||value.company?.name!==company.name
      ||!Array.isArray(value.files)||value.files.length!==names.length||value.files.some((name,index)=>name!==names[index]))throw Error('다른 파일이 첨부되었거나 검증을 이미 요청했습니다.');
    return document.body.innerText||'';
  };
  let revealingCompany=false;
  for(let attempt=0;attempt<80;attempt++){
    let text=readCurrent(),codes=Array.from(text.matchAll(/Company Code:\s*(A\d+)\b/g),match=>match[1]);
    // Upload redraws can close the menu while files are still appearing. Reopen
    // it without resetting inputs, and require the full code before returning.
    if(!codes.length&&!revealingCompany){
      const menus=Array.from(document.querySelectorAll('button')).filter(button=>button.getClientRects().length&&!button.disabled&&(button.innerText||'').trim()===company.name);
      if(menus.length!==1)throw Error('업로드 중 Supplier Hub 회사 메뉴를 확인하지 못했습니다.');
      menus[0].click();revealingCompany=true;
      text=readCurrent();codes=Array.from(text.matchAll(/Company Code:\s*(A\d+)\b/g),match=>match[1]);
    }
    if(codes.length){
      if(codes.length!==1||codes[0]!==company.code)throw Error('업로드 중 Supplier Hub 회사가 변경되었습니다.');
      revealingCompany=false;
      const visible=text.split(/[\s<>"'(),;]+/);
      if(names.every(name=>visible.includes(name)))return true;
    }
    await new Promise(resolve=>setTimeout(resolve,250));
  }
  return false;
}
